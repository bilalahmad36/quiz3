package com.example.bilal

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
